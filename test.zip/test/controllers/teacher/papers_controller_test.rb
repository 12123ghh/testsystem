require 'test_helper'

class Teacher::PapersControllerTest < ActionDispatch::IntegrationTest
	
	# test "should create paper " do
	# 	post teacher_papers_path
	# end
end
